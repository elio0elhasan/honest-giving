import React from 'react';
import { Brain, Github, Linkedin, Mail, Phone, Rocket, ScrollText, GraduationCap, Code, BookOpen, MessageSquare } from 'lucide-react';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Projects } from './components/Projects';
import { Certifications } from './components/Certifications';
import { Future } from './components/Future';
import { Contact } from './components/Contact';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-sky-50 to-purple-50">
      <Navigation />
      <main>
        <Hero />
        <About />
        <Projects />
        <Certifications />
        <Future />
        <Contact />
      </main>
    </div>
  );
}

export default App;