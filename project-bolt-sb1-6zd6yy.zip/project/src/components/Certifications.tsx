import React from 'react';
import { Award, CheckCircle } from 'lucide-react';

export function Certifications() {
  const certifications = [
    {
      title: 'Data Scientist Professional',
      provider: '365 Data Science',
      date: '2023',
      skills: ['Machine Learning', 'Statistical Analysis', 'Python'],
    },
    {
      title: 'Introduction to NLP for AI',
      provider: '365 Data Science',
      date: '2023',
      skills: ['Natural Language Processing', 'Text Analysis', 'NLTK'],
    },
    {
      title: 'Credit Risk Modeling in Python',
      provider: '365 Data Science',
      date: '2023',
      skills: ['Risk Analysis', 'Financial Modeling', 'Python'],
    },
  ];

  return (
    <section id="certifications" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-center mb-16 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-transparent bg-clip-text">
          Certifications & Skills
        </h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {certifications.map((cert, index) => (
            <div key={index} className="bg-gradient-to-br from-orange-50 via-sky-50 to-purple-50 p-8 rounded-xl shadow-lg">
              <div className="flex items-center gap-4 mb-6">
                <Award className="w-10 h-10 text-purple-600" />
                <div>
                  <h3 className="text-xl font-bold">{cert.title}</h3>
                  <p className="text-gray-600">{cert.provider}</p>
                </div>
              </div>
              
              <div className="space-y-3">
                {cert.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span>{skill}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 grid md:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-xl shadow-lg">
            <h3 className="text-2xl font-bold mb-6">Technical Skills</h3>
            <div className="grid grid-cols-2 gap-4">
              <SkillCategory
                title="Machine Learning"
                skills={['Supervised Learning', 'Unsupervised Learning', 'Reinforcement Learning']}
              />
              <SkillCategory
                title="Deep Learning"
                skills={['Neural Networks', 'CNN', 'RNN', 'Transformers']}
              />
              <SkillCategory
                title="Tools & Libraries"
                skills={['TensorFlow', 'PyTorch', 'Scikit-learn', 'Pandas']}
              />
              <SkillCategory
                title="Specializations"
                skills={['Computer Vision', 'NLP', 'Time Series Analysis']}
              />
            </div>
          </div>
          
          <div className="bg-white p-8 rounded-xl shadow-lg">
            <h3 className="text-2xl font-bold mb-6">Professional Skills</h3>
            <div className="grid grid-cols-2 gap-4">
              <SkillCategory
                title="Development"
                skills={['Git Version Control', 'Docker', 'API Development']}
              />
              <SkillCategory
                title="Data Skills"
                skills={['Data Preprocessing', 'Feature Engineering', 'Model Deployment']}
              />
              <SkillCategory
                title="Soft Skills"
                skills={['Problem Solving', 'Team Collaboration', 'Communication']}
              />
              <SkillCategory
                title="Industry Knowledge"
                skills={['AI Ethics', 'MLOps', 'Research Methods']}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function SkillCategory({ title, skills }: { title: string; skills: string[] }) {
  return (
    <div>
      <h4 className="font-semibold mb-2 text-purple-600">{title}</h4>
      <ul className="space-y-1">
        {skills.map((skill, index) => (
          <li key={index} className="text-gray-600">
            {skill}
          </li>
        ))}
      </ul>
    </div>
  );
}