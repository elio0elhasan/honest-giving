import React from 'react';
import { Github, Linkedin, Brain } from 'lucide-react';

export function Hero() {
  return (
    <section id="home" className="pt-20 min-h-screen flex items-center relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 via-sky-500/10 to-purple-500/10" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center">
          <div className="flex justify-center mb-8">
            <Brain className="w-24 h-24 text-purple-600" />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-transparent bg-clip-text">
            Machine Learning Engineer
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto">
            Transforming data into intelligence through innovative AI solutions
          </p>
          
          <div className="flex justify-center gap-6">
            <SocialLink href="https://github.com/el-hassan-uthman" icon={<Github />} label="GitHub" />
            <SocialLink href="https://linkedin.com/in/el-hassan-u-mustafa-90725226a" icon={<Linkedin />} label="LinkedIn" />
          </div>
        </div>
      </div>
    </section>
  );
}

function SocialLink({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-white shadow-lg hover:shadow-xl transition-shadow text-gray-700 hover:text-purple-600"
      aria-label={label}
    >
      {icon}
    </a>
  );
}