import React from 'react';
import { GraduationCap, Code, Brain } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-center mb-16 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-transparent bg-clip-text">
          About Me
        </h2>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
              alt="AI Neural Network Visualization"
              className="rounded-lg shadow-2xl transform hover:scale-105 transition-transform duration-300"
            />
          </div>
          
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <GraduationCap className="w-8 h-8 text-orange-500" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Education</h3>
                <p className="text-gray-600">Fresh graduate from Arab Open University with a passion for artificial intelligence and machine learning.</p>
              </div>
            </div>
            
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <Code className="w-8 h-8 text-sky-500" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Technical Expertise</h3>
                <p className="text-gray-600">Specialized in Machine Learning, Deep Learning, NLP, and Computer Vision using cutting-edge technologies like TensorFlow and PyTorch.</p>
              </div>
            </div>
            
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <Brain className="w-8 h-8 text-purple-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Vision</h3>
                <p className="text-gray-600">Committed to pushing the boundaries of AI technology and creating innovative solutions that make a real-world impact.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}