import React from 'react';
import { Rocket, Brain, Target, Lightbulb } from 'lucide-react';

export function Future() {
  return (
    <section id="future" className="py-20 bg-gradient-to-br from-orange-50 via-sky-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-center mb-16 bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 text-transparent bg-clip-text">
          Future Aspirations
        </h2>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div className="bg-white p-8 rounded-xl shadow-xl">
            <div className="flex items-center gap-4 mb-6">
              <Brain className="w-12 h-12 text-purple-600" />
              <h3 className="text-2xl font-bold">Master's in AI</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Planning to pursue a Master's degree specializing in either Computer Vision or Natural Language Processing,
              focusing on cutting-edge research and advanced AI applications.
            </p>
            <div className="space-y-4">
              <FuturePoint
                icon={<Target className="w-6 h-6 text-orange-500" />}
                title="Research Focus"
                description="Contribute to groundbreaking research in AI/ML field"
              />
              <FuturePoint
                icon={<Lightbulb className="w-6 h-6 text-sky-500" />}
                title="Innovation"
                description="Develop novel approaches to solving complex AI challenges"
              />
              <FuturePoint
                icon={<Rocket className="w-6 h-6 text-pink-500" />}
                title="Impact"
                description="Create AI solutions that benefit society and industry"
              />
            </div>
          </div>
          
          <div className="space-y-8">
            <FutureCard
              title="Specialization Goals"
              description="Deep dive into advanced topics in Computer Vision or NLP, including transformer architectures, few-shot learning, and multimodal AI systems."
              className="bg-gradient-to-r from-orange-500 to-pink-500"
            />
            
            <FutureCard
              title="Research Interests"
              description="Exploring the intersection of AI with healthcare, autonomous systems, or language understanding, pushing the boundaries of what's possible."
              className="bg-gradient-to-r from-sky-500 to-purple-500"
            />
            
            <FutureCard
              title="Industry Impact"
              description="Applying advanced AI techniques to solve real-world problems, bridging the gap between academic research and practical applications."
              className="bg-gradient-to-r from-pink-500 to-purple-500"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

function FuturePoint({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="flex items-start gap-4">
      <div className="flex-shrink-0">{icon}</div>
      <div>
        <h4 className="font-semibold mb-1">{title}</h4>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
}

function FutureCard({ title, description, className }: { title: string; description: string; className: string }) {
  return (
    <div className={`p-6 rounded-xl text-white ${className}`}>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-white/90">{description}</p>
    </div>
  );
}